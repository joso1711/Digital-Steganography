package stego;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class LSBEncoder {

    public static void encodeMessage(List<BufferedImage> images, String message) {
        byte[] messageBytes = message.getBytes();
        int messageLength = messageBytes.length;
        int totalBitsNeeded = 32 + messageLength * 8;

        List<Integer> messageBits = new ArrayList<>();

        // Add 32-bit message length
        for (int i = 31; i >= 0; i--) {
            messageBits.add((messageLength >> i) & 1);
        }

        for (byte b : messageBytes) {
            for (int i = 7; i >= 0; i--) {
                messageBits.add((b >> i) & 1);
            }
        }

        int bitIndex = 0;
        outer:
        for (BufferedImage image : images) {
            for (int y = 0; y < image.getHeight(); y++) {
                for (int x = 0; x < image.getWidth(); x++) {
                    int rgb = image.getRGB(x, y);
                    int r = (rgb >> 16) & 0xFF;
                    int g = (rgb >> 8) & 0xFF;
                    int b = rgb & 0xFF;

                    if (bitIndex < messageBits.size()) r = (r & 0xFE) | messageBits.get(bitIndex++);
                    if (bitIndex < messageBits.size()) g = (g & 0xFE) | messageBits.get(bitIndex++);
                    if (bitIndex < messageBits.size()) b = (b & 0xFE) | messageBits.get(bitIndex++);

                    int newRGB = (r << 16) | (g << 8) | b;
                    image.setRGB(x, y, newRGB);

                    if (bitIndex >= messageBits.size()) break outer;
                }
            }
        }

        if (bitIndex < messageBits.size()) {
            throw new IllegalArgumentException("Message too large for selected images.");
        }
    }
}
