package stego;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class LSBDecoder {

    public static String decodeFromImages(List<BufferedImage> images) {
        List<Integer> bits = new ArrayList<>();

        for (BufferedImage image : images) {
            for (int y = 0; y < image.getHeight(); y++) {
                for (int x = 0; x < image.getWidth(); x++) {
                    int rgb = image.getRGB(x, y);
                    bits.add((rgb >> 16) & 1); // Red
                    bits.add((rgb >> 8) & 1);  // Green
                    bits.add(rgb & 1);         // Blue
                }
            }
        }

        if (bits.size() < 32) return "Not enough data to decode length.";

        int messageLength = 0;
        for (int i = 0; i < 32; i++) {
            messageLength = (messageLength << 1) | bits.get(i);
        }

        int totalBits = messageLength * 8;
        if (bits.size() < 32 + totalBits) return "Error: Not enough data to decode the message.";

        byte[] messageBytes = new byte[messageLength];
        for (int i = 0; i < messageLength; i++) {
            int b = 0;
            for (int j = 0; j < 8; j++) {
                b = (b << 1) | bits.get(32 + i * 8 + j);
            }
            messageBytes[i] = (byte) b;
        }

        return new String(messageBytes);
    }
}
