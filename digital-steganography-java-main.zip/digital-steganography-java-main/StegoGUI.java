package stego;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import javax.imageio.ImageIO;

public class StegoGUI extends JFrame {

    private final Map<File, JTextField> imageMessageMap = new LinkedHashMap<>();
    private final JPanel originalPanel = new JPanel();
    private final JPanel stegoPanel = new JPanel();
    private final JTextArea outputArea = new JTextArea(4, 30);
    private final File stegoDir = new File("stego");

    public StegoGUI() {
        setTitle("LSB Steganography with AES Encryption");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JButton loadBtn = new JButton("Select Images");
        JButton encodeBtn = new JButton("Encode");
        JButton decodeBtn = new JButton("Decode");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(loadBtn);
        buttonPanel.add(encodeBtn);
        buttonPanel.add(decodeBtn);

        originalPanel.setLayout(new BoxLayout(originalPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollOriginal = new JScrollPane(originalPanel);
        scrollOriginal.setPreferredSize(new Dimension(700, 300));
        scrollOriginal.setBorder(BorderFactory.createTitledBorder("Selected Images + Messages"));

        stegoPanel.setLayout(new FlowLayout());
        JScrollPane scrollStego = new JScrollPane(stegoPanel);
        scrollStego.setPreferredSize(new Dimension(700, 200));
        scrollStego.setBorder(BorderFactory.createTitledBorder("Stego Image Previews"));

        outputArea.setEditable(false);
        JScrollPane outputScroll = new JScrollPane(outputArea);

        JPanel outputPanel = new JPanel(new BorderLayout());
        outputPanel.add(new JLabel("Decoded Message:"), BorderLayout.NORTH);
        outputPanel.add(outputScroll, BorderLayout.CENTER);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollOriginal, BorderLayout.CENTER);
        add(scrollStego, BorderLayout.SOUTH);
        add(outputPanel, BorderLayout.EAST);

        // Load images
        loadBtn.addActionListener(e -> {
            imageMessageMap.clear();
            originalPanel.removeAll();

            JFileChooser chooser = new JFileChooser();
            chooser.setMultiSelectionEnabled(true);
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

            int option = chooser.showOpenDialog(this);
            if (option == JFileChooser.APPROVE_OPTION) {
                File[] selectedFiles = chooser.getSelectedFiles();
                for (File file : selectedFiles) {
                    try {
                        BufferedImage img = ImageIO.read(file);
                        JTextField messageField = new JTextField(25);

                        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
                        Image scaled = img.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                        row.add(new JLabel(new ImageIcon(scaled)));
                        row.add(new JLabel("Message:"));
                        row.add(messageField);

                        originalPanel.add(row);
                        imageMessageMap.put(file, messageField);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                originalPanel.revalidate();
                originalPanel.repaint();
            }
        });

        // Encode
        encodeBtn.addActionListener(e -> {
            String password = JOptionPane.showInputDialog(this, "Enter password for encryption:");
            if (password == null || password.isEmpty()) return;

            stegoPanel.removeAll();
            if (!stegoDir.exists()) stegoDir.mkdir();

            int index = 0;
            for (Map.Entry<File, JTextField> entry : imageMessageMap.entrySet()) {
                try {
                    BufferedImage img = ImageIO.read(entry.getKey());
                    String msg = entry.getValue().getText();
                    if (msg.isEmpty()) continue;

                    String encrypted = CryptoUtils.encrypt(msg, password);

                    BufferedImage copy = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
                    Graphics g = copy.getGraphics();
                    g.drawImage(img, 0, 0, null);
                    g.dispose();

                    LSBEncoder.encodeMessage(Collections.singletonList(copy), encrypted);

                    File out = new File(stegoDir, "stego_" + index + ".png");
                    ImageIO.write(copy, "png", out);

                    BufferedImage saved = ImageIO.read(out);
                    stegoPanel.add(new JLabel(new ImageIcon(saved.getScaledInstance(150, 150, Image.SCALE_SMOOTH))));
                    index++;

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

            stegoPanel.revalidate();
            stegoPanel.repaint();
        });

        // Decode
        decodeBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(stegoDir);
            int option = chooser.showOpenDialog(this);
            if (option == JFileChooser.APPROVE_OPTION) {
                try {
                    BufferedImage img = ImageIO.read(chooser.getSelectedFile());
                    String password = JOptionPane.showInputDialog(this, "Enter password to decrypt:");
                    if (password == null || password.isEmpty()) return;

                    String encodedMsg = LSBDecoder.decodeFromImages(Collections.singletonList(img));
                    String decrypted = CryptoUtils.decrypt(encodedMsg, password);
                    outputArea.setText(decrypted);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Decryption failed. Wrong password or corrupted data.");
                }
            }
        });

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StegoGUI::new);
    }
}
